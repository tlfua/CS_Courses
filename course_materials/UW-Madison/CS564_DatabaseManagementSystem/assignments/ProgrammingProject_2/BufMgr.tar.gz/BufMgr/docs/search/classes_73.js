var searchData=
[
  ['slotinuseexception',['SlotInUseException',['../classbadgerdb_1_1_slot_in_use_exception.html',1,'badgerdb']]]
];
